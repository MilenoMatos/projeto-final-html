Segue os dois links para acessar os video no drive, 
basta estar logado com uma conta instituiconal da utfpr para obter acesso sem a necessidade de pedir permissão.

Nome: Mileno Oliveira Matos RA: a2352656
Nome: Nicolas Bortolotto Willi RA: a2335670

Foram alterados alguns detalhes que não são mostrados nos videos, como por exemplo: titulo de cada pagina html, nome de arquivo js que estava errado.
E acabamos não sitando nos videos, mas foi usada a metodlogia BEM.
O segundo video por algum motivo durante a renederização, ele adicionou parte do video fica preto, não era pra ter nenhum conteudo ali, quando a gravação é encerrada dever acabar,
mas acredito ter sido um erro de render, fiz usando no Sony Vegas, embora esteja publicando o video assim, não tem nenhum erro no conteudo em si, apenas após.

Link com visualização do site: https://drive.google.com/file/d/1UKSaeriUNKJ2RY7WizUfUEANthZXcl97/view?usp=sharing

link com visualização do codigo: https://drive.google.com/file/d/1o8WqjQ887lLzjpDFXlN_P8eR0SZF1xLs/view?usp=sharing

Por algum motivo no google drive está deixando a qualidade da imagem muito ruim, pode ser apenas pra mim, então vou postar no youtube tambem, e deixarei ambos os links aqui.
Então você pode assistir pelo q estiver melhor.

Link com visualização do site: https://www.youtube.com/watch?v=OWmZ8b4YdSo

link com visualização do codigo: https://www.youtube.com/watch?v=usmyD-SPEiA&feature=youtu.be
